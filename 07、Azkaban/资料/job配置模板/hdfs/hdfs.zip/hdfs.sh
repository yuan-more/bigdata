#!/bin/bash
/export/servers/hadoop-2.7.5/bin/hadoop fs -mkdir /azaz666