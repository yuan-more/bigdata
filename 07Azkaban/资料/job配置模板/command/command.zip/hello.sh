#!/bin/bash
date  > /root/hello.txt